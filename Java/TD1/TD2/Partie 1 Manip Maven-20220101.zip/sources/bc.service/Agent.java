
package bc.service;



public class Agent extends Personne implements IAgent
{
    private final int SALAIREMIN = 1150;
    private int _salaire;
    private String _fonction;
    
    public Agent(String nom,int age,String fonction,int salaire)
    {
        super(nom,age);
        _salaire = Math.max(salaire,SALAIREMIN);
        _fonction = fonction;
    }


    public String getFonction() {
        return _fonction;
    }

    public int getSalaireNet() {
        return _salaire;
    }
    
    @Override 
    public String toString()
    {
        return "Agent (" + super.toString() + ") :" + _fonction;
    }
    
            
}
