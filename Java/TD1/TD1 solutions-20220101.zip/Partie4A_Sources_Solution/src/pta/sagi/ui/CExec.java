package pta.sagi.ui;

public class CExec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
