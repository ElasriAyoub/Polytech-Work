-- Création de base
CREATE DATABASE IF NOT EXISTS db_personne 
DEFAULT CHARACTER SET utf8 COLLATE utf8_swedish_ci;
-- 
USE db_personne;

-- Création de table
CREATE TABLE IF NOT EXISTS personne
(
 id INTEGER NOT NULL AUTO_INCREMENT,
 nom VARCHAR(15) NOT NULL DEFAULT '?',
 age SMALLINT NOT NULL,
 PRIMARY KEY (id)
) 
ENGINE=InnoDB  DEFAULT CHARSET=utf8 
COLLATE=utf8_swedish_ci AUTO_INCREMENT=1;


-- PEUPLER la table
INSERT INTO personne (nom,age) VALUES 
('Bécassine',45),('Milou',7),('Jacques',28),
('Pierre',34),('Romain',27),('Louis',15),
('Marie',32),('Elodie',38),('Alexandre',25);
