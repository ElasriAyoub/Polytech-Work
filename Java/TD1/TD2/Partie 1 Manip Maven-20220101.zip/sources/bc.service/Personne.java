/** 
 * @author bertrand cottenceau
 */
package bc.service;

public class Personne 
{
    private String _nom;
    private int _age;
    
    public Personne(String nom,int age){
        _nom=nom;
        _age=age;
    }
    
    public String getNom(){ return _nom;}
    
    public int getAge(){ return _age;}
    
    @Override
    public String toString(){
        return _nom + " " + Integer.toString(_age) + " ans";
    }    
}
