package bc.service;

public class ChefService extends Agent
{
    public ChefService(String nom,int age,int salaire)
    {
        super(nom,age,"Chef de Service",salaire);
    }       
}
