package bc.service;

public class ServiceStat extends Service
{
    public ServiceStat(String nomService,ChefService chef)
    {
        super(nomService,chef);
    }
    
    public float getSalaireMoyen()
    {
        float sommeSalaire=getChef().getSalaireNet();
        for(int i=0;i<getTaille();i++)
        {
            sommeSalaire+=getAgent(i).getSalaireNet();
        }
        return sommeSalaire/(getTaille()+1);
    }
    
    public float getAgeMoyen(){       
        float sommeAge=getChef().getAge();
        for(int i=0;i<getTaille();i++)
        {
            sommeAge+=getAgent(i).getAge();
        }
        return sommeAge/(getTaille()+1);
    }
    
    @Override 
    public String toString()
    {
      String s1 = String.format("%.2f",getAgeMoyen());
      String s2 = String.format("%.2f",getSalaireMoyen());     
        
        return "Service " + this.getNomService() + " age moy.:" + 
                s1 + " salaire moy.:" +s2;
          
    }
    
    
}
