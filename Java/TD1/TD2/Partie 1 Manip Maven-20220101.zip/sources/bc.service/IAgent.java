package bc.service;

public interface IAgent 
{
    String getFonction();
    int getSalaireNet();    
}
