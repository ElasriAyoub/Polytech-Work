package bc.service;

import java.util.ArrayList;

public class Service 
{
    private String _nomService;
    private ArrayList<Agent> _personnel;
    private ChefService _chef;
    
    public Service(String nomService,ChefService chef)
    {
        _nomService=nomService;
        _chef=chef;
        _personnel = new ArrayList<Agent>();        
    }
    
    public void add(Agent a)
    {
        if(a!=null) _personnel.add(a);
    }
    
    public Agent getAgent(int idxAgent){
        return _personnel.get(idxAgent);
    }
    
    public String getNomService()
    {
        return this._nomService;
    }
    public ChefService getChef(){
        return _chef;
    }
    public int getTaille(){   return _personnel.size(); }
    
    @Override 
    public String toString(){
        return "Service " + this._nomService + "[chef:" + _chef.toString() + "]";
    }
}
